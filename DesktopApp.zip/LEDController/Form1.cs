﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace LEDController
{
    public partial class Form1 : Form
    {
        //private int button;
        private byte R = 255;
        private byte G = 255;
        private byte B = 255;
        private String[] portNames;
        private String[] allFiles;
        Random rand = new Random();
        private bool play = false;
        private String pos = "";
        private String dir = "";

        private void trackBar3_ValueChanged(object sender, EventArgs e)
        {
            G = (byte)trackBar3.Value;
            label3.Text = "Green: " + G.ToString();
            
        }

        private void trackBar4_ValueChanged(object sender, EventArgs e)
        {
            B = (byte)trackBar4.Value;
            label4.Text = "Blue: " + B.ToString();
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            label1.Text = b.Text;
            serialPort1.Write("!L4");
            serialPort1.Write(new byte[] { 0x00 }, 0, 1);
            serialPort1.Write("!L4");
            serialPort1.Write(new byte[] { 0x00 }, 0, 1);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            label1.Text = b.Text;
            serialPort1.Write("!L1");
            serialPort1.Write(new byte[] { 0x00 }, 0, 1);
            serialPort1.Write("!L1");
            serialPort1.Write(new byte[] { 0x00 }, 0, 1);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            label1.Text = b.Text;
            serialPort1.Write("!L2");
            serialPort1.Write(new byte[] { 0x00 }, 0, 1);
            serialPort1.Write("!L2");
            serialPort1.Write(new byte[] { 0x00 }, 0, 1);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            label1.Text = b.Text;
            serialPort1.Write("!L3");
            serialPort1.Write(new byte[] { 0x00 }, 0, 1);
            serialPort1.Write("!L3");
            serialPort1.Write(new byte[] { 0x00 }, 0, 1);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            label1.Text = b.Text;
            serialPort1.Write("!L5");
            label1.Text = b.Text;
            serialPort1.Write("!L5");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            label1.Text = b.Text;
            serialPort1.Write("!L6");
            serialPort1.Write(new byte[] { 0x00 }, 0, 1);
            serialPort1.Write("!L6");
            serialPort1.Write(new byte[] { 0x00 }, 0, 1);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            label1.Text = b.Text;
            serialPort1.Write("!L7");
            serialPort1.Write(new byte[] { 0x00 }, 0, 1);
            serialPort1.Write("!L7");
            serialPort1.Write(new byte[] { 0x00 }, 0, 1);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            label1.Text = b.Text;
            serialPort1.Write("!L8");
            serialPort1.Write(new byte[] { 0x00 }, 0, 1);
            serialPort1.Write("!L8");
            serialPort1.Write(new byte[] { 0x00 }, 0, 1);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            label1.Text = b.Text;
            serialPort1.Write("!L9");
            serialPort1.Write(new byte[] { 0x00 }, 0, 1);
            serialPort1.Write("!L9");
            serialPort1.Write(new byte[] { 0x00 }, 0, 1);
        }

        private void comboBox1_SelectedValueChanged(object sender, EventArgs e)
        {
            serialPort1.PortName = comboBox1.SelectedText;
        }

        private void comboBox1_TextUpdate(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen) serialPort1.Close();
            serialPort1.PortName = comboBox1.SelectedText;
            serialPort1.Open();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            String[] newNames = System.IO.Ports.SerialPort.GetPortNames();
            foreach(string s in newNames)
            {
                if (Array.IndexOf(portNames, s) == -1)
                {
                    Array.Resize(ref portNames, portNames.Length + 1);
                    portNames[portNames.Length - 1] = s;
                    comboBox1.Items.Add(s);
                }
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            portNames = System.IO.Ports.SerialPort.GetPortNames();
            string dirScanner = @"g:\music\";
            allFiles = System.IO.Directory.GetFiles(dirScanner, "*.wav");
            /*while (portNames.Length == 0)
            {
                portNames = System.IO.Ports.SerialPort.GetPortNames();

            } */
            foreach (string s in portNames)
            {
                comboBox1.Items.Add(s);
            }
            if (portNames.Length == 0) comboBox1.Items.Add("Test");
            comboBox1.SelectedIndex = 0;
            serialPort1.PortName = comboBox1.Text;
            serialPort1.Open();
            //R = 0;
            //label1.Text = R.ToString();
            //System.Threading.Thread.Sleep(100);
            serialPort1.Write("!B");
            serialPort1.Write(new byte[] { B, 0x00 }, 0, 2);
            //System.Threading.Thread.Sleep(100);
            serialPort1.Write("!G");
            serialPort1.Write(new byte[] { G, 0x00 }, 0, 2);
            //System.Threading.Thread.Sleep(100);
            serialPort1.Write("!R");
            serialPort1.Write(new byte[] { R, 0x00 }, 0, 2);
            timer1.Enabled = false;
        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            System.Threading.Thread.Sleep(100);
            label8.Text = serialPort1.ReadExisting();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void trackBar2_ValueChanged(object sender, EventArgs e)
        {
            R = (byte)trackBar2.Value;
            label2.Text = "Red: " + R.ToString();
            
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            //serialPort1.Write("!M1");
            //serialPort1.Write(new byte[] { 0x00 }, 0, 1);
            if (axWindowsMediaPlayer1.URL.Equals(""))
            {
                dir = allFiles[rand.Next(0, allFiles.Length)];
                while (dir.Substring(9).Equals(label8.Text)) dir = allFiles[rand.Next(0, allFiles.Length)];
                axWindowsMediaPlayer1.URL = dir;
                label8.Text = dir.Substring(9);
                play = true;
            } else if (play)
            {
                axWindowsMediaPlayer1.Ctlcontrols.pause();
                play = false;
            } else
            {
                axWindowsMediaPlayer1.Ctlcontrols.play();
                play = true;
            }

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            axWindowsMediaPlayer1.Ctlcontrols.stop();
            dir = allFiles[rand.Next(0, allFiles.Length)];
            while (dir.Substring(9).Equals(label8.Text)) dir = allFiles[rand.Next(0, allFiles.Length)];
            axWindowsMediaPlayer1.URL = dir;
            label8.Text = dir.Substring(9);
            pos = "";
            play = true;
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                serialPort1.Write("!R");
                serialPort1.Write(new byte[] { R, 0x00 }, 0, 2);
                serialPort1.Write("!G");
                serialPort1.Write(new byte[] { G, 0x00 }, 0, 2);
                serialPort1.Write("!B");
                serialPort1.Write(new byte[] { B, 0x00 }, 0, 2);

            }
            else
            {
                try
                {
                    serialPort1.Open();
                } catch (Exception ee)
                {

                }
            }
        }

        private void axWindowsMediaPlayer1_Enter(object sender, EventArgs e)
        {

        }

        private void axWindowsMediaPlayer1_EndOfStream(object sender, AxWMPLib._WMPOCXEvents_EndOfStreamEvent e)
        {
            axWindowsMediaPlayer1.Ctlcontrols.stop();
            axWindowsMediaPlayer1.URL = allFiles[rand.Next(0, allFiles.Length - 1)];
        }

        private void axWindowsMediaPlayer1_PlayStateChange(object sender, AxWMPLib._WMPOCXEvents_PlayStateChangeEvent e)
        {
            //axWindowsMediaPlayer1.Ctlcontrols.
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            if (play)
            {
                if (axWindowsMediaPlayer1.Ctlcontrols.currentPositionString == pos)
                {
                    axWindowsMediaPlayer1.Ctlcontrols.stop();
                    dir = allFiles[rand.Next(0, allFiles.Length)];
                    while (dir.Substring(9).Equals(label8.Text)) dir = allFiles[rand.Next(0, allFiles.Length)];
                    axWindowsMediaPlayer1.URL = dir;
                    label8.Text = dir.Substring(9);
                }
                pos = axWindowsMediaPlayer1.Ctlcontrols.currentPositionString;
                //label8.Text = pos;
            }
        }
    }
}
