#include "mbed.h"
#include <rtos.h>
#include "uLCD_4DGL.h"
#include <vector>
#include <string>
#include <wave_player.h>
#include <SDFileSystem.h>
#include <Speaker.h>
#include <DotStar.h>
#include <ctime>    // For time()
#include <cstdlib>


Serial pc(USBTX, USBRX);
DigitalOut one(LED1);
DigitalOut two(LED2);
DigitalOut three(LED3);
DigitalOut four(LED4);

Adafruit_DotStar strip(60, p12, p11, p13, 800000, DOTSTAR_BGR);
Thread led;

//const char* c;
string dir;
Mutex spi_lock;
char *a;
char *b;
unsigned int red, orange, yellow, green, blue, violet;

//uLCD_4DGL uLCD(p28, p27, p29);
volatile unsigned char R = 255, G = 255, B = 255;
volatile char ledthread = '0'; 

void led_solid();
void set_strip(unsigned char r, unsigned char g, unsigned char b);
void set_strip(uint32_t rgb);



void led_pulse() { // pulses brightness from 0-50 slowly. Color determined by global vars
unsigned char r = 0, g = 0, b = 0;

    while(ledthread == '8') {
        for (int i = 127; i > 0; i--) {
            if (ledthread != '8') {
                strip.setBrightness(127);
                return;
            }
            strip.setBrightness(i);
            if (r != R || g != G || b != B) {
                r = R;
                g = G;
                b = B;
                for (int i = 0; i < 60; i++) {
                    strip.setPixelColor(i, R, G, B);
                }
                strip.show();
            }
            strip.show();
            Thread::wait(30);
        }
        for (int i = 0; i < 128; i++) {
            if (ledthread != '8') {
                strip.setBrightness(127);
                return;
            }
            strip.setBrightness(i);
            if (r != R || g != G || b != B) {
                r = R;
                g = G;
                b = B;
                for (int i = 0; i < 60; i++) {
                    strip.setPixelColor(i, R, G, B);
                }
                strip.show();
            }
            strip.show();
            Thread::wait(30);
        }
    }
    strip.setBrightness(127);
}

void led_shift() { //number of LEDs lit determined by current frequency of music. Color determined by global vars
    while (ledthread == '9') {
        for (int i = 0; i < 60; i++) {
            for (int j = 0; j <= i; j++) {
                strip.setPixelColor(j, R, G, B);
            }
            for (int j = i + 1; j < 60; j++) {
                strip.setPixelColor(j, 0, 0, 0);
            }
            strip.show();
            if (ledthread != '9') {return;}
            Thread::wait(100);
        }
        for (int i = 59; i >= 0; i--) {
            for (int j = 59; j >= i; j--) {
                strip.setPixelColor(j, 0, 0, 0);
            }
            for (int j = i - 1; j >= 0; j--) {
                strip.setPixelColor(j, R, G, B);
            }
            strip.show();
            if (ledthread != '9') {return;}
            Thread::wait(100);
        }
    }
}

void led_rainbow() { //Repeats pattern of Red-Orange-Yellow-Green-Blue-Voilet down the strip, and shifts that down the strip
    uint32_t colors[60];
    uint32_t tmp;
    uint32_t rainbow[10] = {red, orange, yellow, green, blue, violet, blue, green, yellow, orange};
    for (int i = 0; i < 60; i++) {
        colors[i] = rainbow[i % 10];
        strip.setPixelColor(i, colors[i]);
    }
    strip.show();
    Thread::wait(300);
    while (ledthread == '4') {
        tmp = colors[0];
        for (int i = 1; i < 60; i++) {
            colors[i - 1] = colors[i];
            strip.setPixelColor(i, colors[i]);
        }
        colors[59] = tmp;
        strip.setPixelColor(0, colors[0]);
        strip.show();
        Thread::wait(300);
    }
}

void led_trail() { // Slowly transitions entire strip through color wheel
uint32_t colors[60];
    //uint32_t tmp;
    uint32_t rainbow[10] = {red, orange, yellow, green, blue, violet, blue, green, yellow, orange};
    for (int i = 0; i < 60; i++) {
        colors[i] = rainbow[i % 10];
    }
    while (ledthread == '5') {
        strip.clear();
        for (int i = 1; i < 59; i++) {
            if (ledthread != '5') {return;}
            strip.setPixelColor(i-1, colors[i-1]);
            strip.setPixelColor(i, colors[i]);
            strip.setPixelColor(i+1, colors[i+1]);
            strip.show();
            Thread::wait(25);
            strip.clear();
        }
        for (int i = 59; i > 0; i--) {
            if (ledthread != '5') {return;}
            strip.setPixelColor(i-1, colors[i-1]);
            strip.setPixelColor(i, colors[i]);
            strip.setPixelColor(i+1, colors[i+1]);
            strip.show();
            Thread::wait(25);
            strip.clear();
        }
    }
}

void led_flash() {
    uint32_t rainbow[10] = {red, orange, yellow, green, blue, violet, blue, green, yellow, orange};
    while (ledthread == '3') {
        set_strip(rainbow[rand() % 10]);
        Thread::wait(300);
        if (ledthread != '3') return;
        strip.clear();
        strip.show();
        Thread::wait(300);
    }
}

void led_fade() {
    set_strip(255, 0, 0);
    uint8_t r = 255, g = 0, b = 0;
    while (ledthread == '2') {
        while (g < 255) {
            if (ledthread != '2') return;
            g++;
            set_strip(r, g, b);
            Thread::wait(5);
        } while (r > 0) {
            if (ledthread != '2') return;
            r--;
            set_strip(r, g, b);
            Thread::wait(5);
        } while (b < 255) {
            if (ledthread != '2') return;
            b++;
            set_strip(r, g, b);
            Thread::wait(5);
        } while (g > 0) {
            if (ledthread != '2') return;
            g--;
            set_strip(r, g, b);
            Thread::wait(5);
        } while (r < 255) {
            if (ledthread != '2') return;
            r++;
            set_strip(r, g, b);
            Thread::wait(5);
        } while (b > 0) {
            if (ledthread != '2') return;
            b--;
            set_strip(r, g, b);
            Thread::wait(5);
        }
    }
}

void led_random() {
    uint32_t rainbow[10] = {red, orange, yellow, green, blue, violet, blue, green, yellow, orange};
    while (ledthread == '6') {
        for (int i = 0; i < 10; i++) {
            strip.setPixelColor(rand() % 60, rainbow[rand() % 10]);
        }
        strip.show();
        Thread::wait(500);
    }
}

void set_strip(unsigned char r, unsigned char g, unsigned char b) {
    uint32_t tmp = strip.Color(r, g, b);
    for (int i = 0; i < 60; i++) {
        strip.setPixelColor(i, tmp);
    }
    strip.show();
}
void set_strip(uint32_t tmp) {
    //uint32_t tmp = strip.Color(r, g, b);
    for (int i = 0; i < 60; i++) {
        strip.setPixelColor(i, tmp);
    }
    strip.show();
}

void led_main() {
    while(1) {
        //pc.puts("test");
        switch(ledthread) {
            case '2': led_fade();
                break;
            case '3': led_flash();
                break;
            case '4': led_rainbow();
                break;
            case '5': led_trail();
                break;
            case '6': led_random();
                break;
            case '7': led_solid();
                break;
            case '8': led_pulse();
                break;
            case '9': led_shift();
                break;
            default: break;
        }
    }
}

/*
Main Thread. Handles communication with the C# app.
Recieves commands in the format "!<type><argument>\0"
Types:
R: Takes an argument of 0-255 as a byte. Changes global unsigned char R for red LED color.
G: Takes an argument of 0-255 as a byte. Changes global unsigned char G for green LED color.
B: Takes an argument of 0-255 as a byte. Changes global unsigned char B for blue LED color.
L: Takes an argument of '1' - '9' as a char. Changes LED thread, or terminates LED thread if argument is '1'
M: Takes an argument of '1' or '0' as a char. '1' toggles the play/pause global variable, and '0' changes the skip global variable to true.

*/
int main() {
    pc.baud(9600);
    strip.begin();
    strip.setBrightness(127);
    strip.clear();
    strip.show();
     red = strip.Color(255, 0, 0);
     orange = strip.Color(255, 40, 0);
     yellow = strip.Color(255, 255, 0);
     green = strip.Color(0, 255, 0);
     blue = strip.Color(0, 0, 255);
     violet = strip.Color(238, 130, 238);
    char c;
    while(1) {
        while(!pc.readable()) {Thread::wait(1);}
        if (pc.getc() == '!') {
            c = pc.getc();
            if (c == 'R') {
                R = (unsigned char)pc.getc();
            }
            if (c == 'G') {
                G = (unsigned char)pc.getc();
            }
            if (c == 'B') {
                B = (unsigned char)pc.getc();
            }
            if (c == 'L') {
                c = pc.getc();
                if (ledthread != c) {
                    //led.terminate();
                    ledthread = c;
                    switch(c) {
                        case '1': led.terminate();
                        strip.setBrightness(127);
                        strip.clear();
                        strip.show();
                        break;
                        default: if (led.get_state() == Thread::Deleted || led.get_state() == Thread::Inactive) {
                            led.start(led_main);
                        }
                        break;
                    }
                }
            }
            
        }
    //pc.putc(ledthread);
    Thread::wait(10);
    }
}

void led_solid() {// Solid color
    //pc.puts("test");
    while (ledthread == '7') {
        //spi_lock.lock();
        //uint32_t rgb = strip.Color(R, G, B);
        for (int i = 0; i < 60; i++) {
            strip.setPixelColor(i, R, G, B);
        }
        spi_lock.lock();
        strip.show();
        spi_lock.unlock();
        Thread::wait(10);
    }
}